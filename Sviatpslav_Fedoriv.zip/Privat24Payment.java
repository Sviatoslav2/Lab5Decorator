public class Privat24Payment implements PaymentStrategy {
    public boolean pay(double sum) {
        System.out.print("Vivat Colomoiski!!!");
        return true;
    }
}
