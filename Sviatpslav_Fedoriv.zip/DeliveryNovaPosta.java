import java.util.ArrayList;


public class DeliveryNovaPosta implements DeliveryStrtegy {
    public boolean deliver(ArrayList<Bouquet> lst) {
        System.out.print("It was deliver by Nova Posta !");
        return true;
    }
}