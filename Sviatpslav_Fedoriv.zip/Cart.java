import java.util.ArrayList;

public class Cart {
    private PaymentStrategy typeOfPaymentStrategy;
    private DeliveryStrtegy typeOfDeliveryStrtegy;
    public ArrayList<Bouquet> lst = new ArrayList<Bouquet>();


    public Cart(PaymentStrategy typeOfPaymentStrategy, DeliveryStrtegy typeOfDeliveryStrtegy) {
        this.typeOfPaymentStrategy = typeOfPaymentStrategy;
        this.typeOfDeliveryStrtegy = typeOfDeliveryStrtegy;
    }
    public boolean pay(double sum){
        return this.typeOfPaymentStrategy.pay(sum);
    }
    public boolean deliver(ArrayList<Bouquet> lstOfDeliver){
        return this.typeOfDeliveryStrtegy.deliver(lstOfDeliver);
    }
    public boolean ship(){
        System.out.print("Every thing was shiped!");
        return true;
    }
    public double ComputTotalPrise(){
        double sum = 0;
        for(int i=0;i<lst.size();i++){
            sum+=lst.get(i).get_price();
        }
        return sum;
    }
}
