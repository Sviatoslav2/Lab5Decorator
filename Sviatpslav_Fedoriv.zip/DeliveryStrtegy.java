import java.util.ArrayList;


public interface DeliveryStrtegy {
    public boolean deliver(ArrayList<Bouquet> lst);
}
