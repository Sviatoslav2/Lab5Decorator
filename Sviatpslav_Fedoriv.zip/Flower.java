public abstract class Flower {
    public boolean isAlive;
    public int length;
    public boolean smel;
    public double price;
}
