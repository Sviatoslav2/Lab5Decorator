import java.util.ArrayList;
public class Bouquet {
    ArrayList<Flower> lst = new ArrayList<Flower>();
    public double get_price(){
        double sum = 0;
        for(int i= 0; i<lst.size();i++){
            sum = lst.get(i).price + sum;
        }
        return sum;
    }
    public void deleteFlower(Flower flower){lst.remove(flower);}
    public void add_to_bouguet(Flower flower){
        lst.add(flower);
    }
    @Override
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("These is bouguet"+"\n");
        for(int i = 0; i<lst.size();i++){
            s.append(lst.get(i).toString()+"\n");
        }
        String str = s.toString();
        return str;
    }
}


