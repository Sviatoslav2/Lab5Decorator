import java.util.Scanner;

public class CashPayment implements PaymentStrategy {
    public boolean pay(double sum) {
        System.out.print("It was payed by cash!");
        return true;
    }
}
